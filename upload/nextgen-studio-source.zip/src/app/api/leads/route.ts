import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { rateLimit } from '@/lib/cache'

// Honeypot + lead capture endpoint for NextGen Digital Studio.
// POST { name, email, phone, company?, service, message?, website(honeypot),
//        utmSource?, utmMedium?, utmCampaign? }

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const PHONE_RE = /^01[3-9]\d{8}$/

const TEN_MIN = 10 * 60 * 1000

export async function POST(req: Request) {
  const headers = { 'Cache-Control': 'no-store' }

  try {
    // Rate limit: 5 submissions per IP per 10 minutes.
    const ip =
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      'unknown'
    if (!rateLimit(`lead:${ip}`, 5, TEN_MIN)) {
      return NextResponse.json(
        { error: 'Too many submissions. Please try again later.' },
        { status: 429, headers },
      )
    }

    const body = await req.json().catch(() => ({} as Record<string, unknown>))
    const {
      name,
      email,
      phone,
      company,
      service,
      message,
      website,
      utmSource,
      utmMedium,
      utmCampaign,
    } = body as Record<string, unknown>

    // Honeypot: if the hidden "website" field is filled, it's a bot.
    // Return a silent 200 so the bot thinks it succeeded.
    if (typeof website === 'string' && website.trim().length > 0) {
      return NextResponse.json({ ok: true }, { status: 200, headers })
    }

    // Validation
    if (typeof name !== 'string' || name.trim().length < 2) {
      return NextResponse.json(
        { error: 'Please enter your name (at least 2 characters).' },
        { status: 400, headers },
      )
    }
    if (typeof email !== 'string' || !EMAIL_RE.test(email.trim())) {
      return NextResponse.json(
        { error: 'Please enter a valid email address.' },
        { status: 400, headers },
      )
    }
    if (typeof phone !== 'string' || !PHONE_RE.test(phone.trim())) {
      return NextResponse.json(
        { error: 'Please enter a valid Bangladeshi phone number (01XXXXXXXXX).' },
        { status: 400, headers },
      )
    }
    if (typeof service !== 'string' || service.trim().length === 0) {
      return NextResponse.json(
        { error: 'Please select a service.' },
        { status: 400, headers },
      )
    }

    const lead = await db.lead.create({
      data: {
        name: name.trim(),
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        company: typeof company === 'string' && company.trim() ? company.trim() : null,
        service: service.trim(),
        message: typeof message === 'string' && message.trim() ? message.trim() : null,
        utmSource: typeof utmSource === 'string' && utmSource.trim() ? utmSource.trim() : null,
        utmMedium: typeof utmMedium === 'string' && utmMedium.trim() ? utmMedium.trim() : null,
        utmCampaign:
          typeof utmCampaign === 'string' && utmCampaign.trim() ? utmCampaign.trim() : null,
      },
    })

    return NextResponse.json({ ok: true, id: lead.id }, { status: 200, headers })
  } catch (err) {
    console.error('[api/leads] error:', err)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500, headers },
    )
  }
}
