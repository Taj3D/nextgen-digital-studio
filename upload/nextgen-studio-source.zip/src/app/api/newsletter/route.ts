import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { rateLimit } from '@/lib/cache'

// Newsletter subscribe endpoint.
// POST { email, source? }

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const TEN_MIN = 10 * 60 * 1000

export async function POST(req: Request) {
  const headers = { 'Cache-Control': 'no-store' }

  try {
    const ip =
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      'unknown'
    if (!rateLimit(`newsletter:${ip}`, 3, TEN_MIN)) {
      return NextResponse.json(
        { error: 'Too many requests. Please try again later.' },
        { status: 429, headers },
      )
    }

    const body = await req.json().catch(() => ({} as Record<string, unknown>))
    const { email, source } = body as Record<string, unknown>

    if (typeof email !== 'string' || !EMAIL_RE.test(email.trim())) {
      return NextResponse.json(
        { error: 'Please enter a valid email address.' },
        { status: 400, headers },
      )
    }

    const cleanEmail = email.trim().toLowerCase()
    const cleanSource =
      typeof source === 'string' && source.trim() ? source.trim() : 'footer'

    await db.newsletter.upsert({
      where: { email: cleanEmail },
      update: { source: cleanSource },
      create: { email: cleanEmail, source: cleanSource },
    })

    return NextResponse.json({ ok: true }, { status: 200, headers })
  } catch (err) {
    console.error('[api/newsletter] error:', err)
    return NextResponse.json(
      { error: 'Something went wrong. Please try again.' },
      { status: 500, headers },
    )
  }
}
