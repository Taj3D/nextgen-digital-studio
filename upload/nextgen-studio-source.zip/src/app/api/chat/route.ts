import { NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'
import { db } from '@/lib/db'
import { rateLimit } from '@/lib/cache'

// AI sales assistant chat endpoint.
// POST { messages: [{role, content}], sessionId }
// Server-only — no 'use client'.

const TEN_MIN = 10 * 60 * 1000

const SYSTEM_PROMPT =
  "You are NextGen Digital Studio's AI sales assistant for Bangladeshi businesses. Reply in the user's language (Bangla or English). Be concise, warm, and sales-oriented. Mention our 60-day ROI guarantee. Encourage booking a free strategy session. Services: AI Lead Capture, AI Follow-Up Automation, AI Sales Chatbot, CRM & Analytics. Pricing: Starter ৳15,000/mo, Growth ৳35,000/mo (most popular), Dominant ৳75,000/mo. Website: nextgenstudio.bd. WhatsApp: +8801711111111. Keep replies under 120 words."

interface ChatMsg {
  role: string
  content: string
}

export async function POST(req: Request) {
  const headers = { 'Cache-Control': 'no-store' }

  try {
    const ip =
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      'unknown'
    if (!rateLimit(`chat:${ip}`, 20, TEN_MIN)) {
      return NextResponse.json(
        { error: 'Too many requests. Please slow down.' },
        { status: 429, headers },
      )
    }

    const body = await req.json().catch(() => ({} as Record<string, unknown>))
    const { messages, sessionId } = body as {
      messages?: ChatMsg[]
      sessionId?: string
    }

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: 'No messages provided.' },
        { status: 400, headers },
      )
    }

    // Sanitize + cap conversation history (last 20 turns to control cost).
    const cleanMessages = messages
      .filter(
        (m) =>
          m &&
          (m.role === 'user' || m.role === 'assistant') &&
          typeof m.content === 'string' &&
          m.content.trim().length > 0,
      )
      .slice(-20)
      .map((m) => ({
        role: m.role as 'user' | 'assistant',
        content: m.content.trim().slice(0, 2000),
      }))

    if (cleanMessages.length === 0) {
      return NextResponse.json(
        { error: 'No valid messages provided.' },
        { status: 400, headers },
      )
    }

    // Resolve / generate sessionId.
    const session =
      typeof sessionId === 'string' && sessionId.trim().length > 0
        ? sessionId.trim()
        : crypto.randomUUID()

    // Call ZAI chat completions with the system prompt prepended.
    const zai = await ZAI.create()
    const res = await zai.chat.completions.create({
      model: 'glm-4.6',
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...cleanMessages,
      ],
    })

    const reply: string =
      res?.choices?.[0]?.message?.content?.trim() ||
      "I'm sorry, I couldn't generate a reply right now. Please try again or WhatsApp us at +8801711111111."

    // Persist the latest user message + the AI reply to the DB.
    const lastUser = cleanMessages[cleanMessages.length - 1]
    const writes: Promise<unknown>[] = []

    if (lastUser.role === 'user') {
      writes.push(
        db.chatMessage.create({
          data: {
            sessionId: session,
            role: 'user',
            content: lastUser.content,
          },
        }),
      )
    }
    writes.push(
      db.chatMessage.create({
        data: {
          sessionId: session,
          role: 'assistant',
          content: reply,
        },
      }),
    )
    await Promise.all(writes)

    return NextResponse.json({ reply, sessionId: session }, { status: 200, headers })
  } catch (err) {
    console.error('[api/chat] error:', err)
    return NextResponse.json(
      { error: 'chat failed' },
      { status: 500, headers },
    )
  }
}
