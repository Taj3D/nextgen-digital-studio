import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, Hind_Siliguri } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/site/theme-provider";
import { LanguageProvider } from "@/components/site/language-provider";
import { SITE_CONFIG } from "@/lib/site-data";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

// Bangla font for native Bengali rendering
const banglaFont = Hind_Siliguri({
  variable: "--font-bangla",
  subsets: ["bengali", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  metadataBase: new URL(SITE_CONFIG.url),
  title: {
    default: "NextGen Digital Studio — AI Sales Automation Agency in Jessore, Bangladesh",
    template: "%s | NextGen Digital Studio",
  },
  description:
    "Stop losing customers. Our AI sales system captures every lead, follows up automatically, and closes deals 24/7 — in fluent Bangla. Built for Bangladeshi businesses. 60-day ROI guarantee.",
  keywords: [
    "AI sales automation Bangladesh",
    "AI chatbot Jessore",
    "lead generation Bangladesh",
    "CRM Bangladesh",
    "AI sales agent Dhaka",
    "Bangla AI chatbot",
    "sales automation Jessore",
    "NextGen Digital Studio",
    "Bengali AI assistant",
    "WhatsApp automation Bangladesh",
  ],
  authors: [{ name: "NextGen Digital Studio" }],
  creator: "NextGen Digital Studio",
  publisher: "NextGen Digital Studio",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  alternates: {
    canonical: SITE_CONFIG.url,
    languages: {
      "en-US": `${SITE_CONFIG.url}/?lang=en`,
      "bn-BD": `${SITE_CONFIG.url}/?lang=bn`,
    },
  },
  openGraph: {
    type: "website",
    locale: "bn_BD",
    alternateLocale: ["en_US"],
    url: SITE_CONFIG.url,
    siteName: "NextGen Digital Studio",
    title: "NextGen Digital Studio — AI Sales Automation Agency",
    description:
      "Stop losing customers. AI sales system that captures every lead, follows up automatically, and closes deals 24/7 — in fluent Bangla. 60-day ROI guarantee.",
    images: [
      {
        url: "/og-image.svg",
        width: 1200,
        height: 630,
        alt: "NextGen Digital Studio — AI Sales Automation Agency in Jessore, Bangladesh",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "NextGen Digital Studio — AI Sales Automation Agency",
    description:
      "Stop losing customers. AI sales system that captures every lead, follows up automatically, and closes deals 24/7 — in fluent Bangla.",
    images: ["/og-image.svg"],
  },
  icons: {
    icon: "/logo.svg",
    apple: "/logo.svg",
  },
  category: "business",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#0fb980" },
    { media: "(prefers-color-scheme: dark)", color: "#0a1a14" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "NextGen Digital Studio",
  alternateName: "নেক্সটজেন ডিজিটাল স্টুডিও",
  url: SITE_CONFIG.url,
  logo: `${SITE_CONFIG.url}/logo.svg`,
  description:
    "AI Sales Automation Agency in Jessore, Bangladesh. We build 24/7 AI sales systems that capture, nurture, and close leads — in Bangla and English.",
  foundingDate: "2023",
  founders: [{ "@type": "Person", name: "NextGen Team" }],
  address: {
    "@type": "PostalAddress",
    addressLocality: "Jessore",
    addressRegion: "Khulna",
    addressCountry: "BD",
    postalCode: "7400",
  },
  contactPoint: [
    {
      "@type": "ContactPoint",
      telephone: SITE_CONFIG.phone,
      contactType: "sales",
      areaServed: "BD",
      availableLanguage: ["Bengali", "English"],
    },
  ],
  sameAs: [
    "https://facebook.com/nextgenstudio.bd",
    "https://linkedin.com/company/nextgen-digital-studio",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="bn" suppressHydrationWarning>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${banglaFont.variable} font-bangla antialiased bg-background text-foreground`}
      >
        <ThemeProvider>
          <LanguageProvider>{children}</LanguageProvider>
        </ThemeProvider>
        <Toaster />
        <SonnerToaster position="bottom-right" />
      </body>
    </html>
  );
}
