// Simple in-memory cache for rate limiting / dedup on the API routes.
// (No external cache middleware — keeps the 4GB container lean.)

type Entry<T> = { value: T; expires: number }

const store = new Map<string, Entry<unknown>>()

export function cacheGet<T>(key: string): T | undefined {
  const e = store.get(key)
  if (!e) return undefined
  if (Date.now() > e.expires) {
    store.delete(key)
    return undefined
  }
  return e.value as T
}

export function cacheSet<T>(key: string, value: T, ttlMs: number) {
  store.set(key, { value, expires: Date.now() + ttlMs })
}

// Rate limiter: returns true if the key is allowed, false if blocked.
// Uses a sliding window per IP-ish key.
const windows = new Map<string, { count: number; resetAt: number }>()

export function rateLimit(key: string, max: number, windowMs: number): boolean {
  const now = Date.now()
  const w = windows.get(key)
  if (!w || now > w.resetAt) {
    windows.set(key, { count: 1, resetAt: now + windowMs })
    return true
  }
  w.count++
  return w.count <= max
}
